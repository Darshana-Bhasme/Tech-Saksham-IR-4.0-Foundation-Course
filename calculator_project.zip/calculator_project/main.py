# -*- coding: utf-8 -*-

import calculator 
 
calculator.operation() 