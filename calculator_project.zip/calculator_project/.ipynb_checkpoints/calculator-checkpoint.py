# -*- coding: utf-8 -*-

def add(num1,num2,num3):
    return num1+num2+num3

def sub(num1,num2,num3):
    return num1-num2-num3

def mul(num1,num2,num3):
    return num1*num2*num3

def div(num1,num2,num3):
    return num1/num2/num3


def operation():
    num1=int(input("enter the 1stnumber"))
    num2=int(input("enter the 2ndnumber"))
    num3=int(input("enter the 3rdnumber"))
    while True:
        print("choice an operation")
        print("addition")
        print("substraction")
        print("multiplication")
        print("division")
        
        choice =input("enter the choice:")
        
        if choice =="1":
            print("result",add(num1,num2,num3))
        elif choice=="2":
            print("result",sub(num1,num2,num3))
        elif choice=="3":
            print("result",mul(num1,num2,num3))
        elif choice=="4":
            print("result",div(num1,num2,num3))
        elif choice=="5":
            print("exit")
            break
        else:
            print("envalid choice")

operation()