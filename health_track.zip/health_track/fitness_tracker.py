import os

class Workout:
    def __init__(self, date, exercise, reps, sets, duration, calories):
        self.date = date
        self.exercise = exercise
        self.reps = reps
        self.sets = sets
        self.duration = duration
        self.calories = calories

    def __str__(self):
        return f"{self.date}: {self.exercise} - {self.reps} reps, {self.sets} sets, {self.duration} min, {self.calories} kcal"

class FitnessTracker:
    def __init__(self, user_name, user_age):
        self.user_name = user_name
        self.user_age = user_age
        self.workouts = []
        self.directory = "user_data"
        os.makedirs(self.directory, exist_ok=True)
        self.filename = os.path.join(self.directory, f"{self.user_name}_workouts.txt")
        
        # 🔹 Automatically Load Data when user logs in
        self.load_previous_workouts()

    def add_workout(self):
        date = input("Enter date (YYYY-MM-DD): ")
        exercise = input("Enter exercise name: ")
        reps = input("Enter reps: ")
        sets = input("Enter sets: ")
        duration = input("Enter duration (mins): ")
        calories = input("Enter calories burned: ")

        workout = Workout(date, exercise, reps, sets, duration, calories)
        self.workouts.append(workout)
        print("Workout added successfully!")

    def load_previous_workouts(self):
        """ 🔹 Loads previous workouts automatically when user logs in """
        if os.path.exists(self.filename):
            with open(self.filename, "r") as file:
                for line in file:
                    date, exercise, reps, sets, duration, calories = line.strip().split(",")
                    self.workouts.append(Workout(date, exercise, reps, sets, duration, calories))
            print(f"✅ Loaded previous data from {self.filename}")

    def load_from_file(self):
        """ Manually load data from a file of user’s choice """
        filename = input("Enter the file name to load data from: ")
        filepath = os.path.join(self.directory, filename)
        try:
            with open(filepath, "r") as file:
                self.workouts = []  # Reset before loading new data
                for line in file:
                    date, exercise, reps, sets, duration, calories = line.strip().split(",")
                    self.workouts.append(Workout(date, exercise, reps, sets, duration, calories))
            print("✅ Data loaded successfully from", filepath)
        except FileNotFoundError:
            print("❌ File not found. Please check the filename and try again.")

    def save_to_file(self):
        """ 🔹 Save data without overwriting previous entries """
        with open(self.filename, "a") as file:  # 🔹 'a' mode to append data instead of overwriting
            for workout in self.workouts[-1:]:  # 🔹 Save only the most recent entry
                file.write(f"{workout.date},{workout.exercise},{workout.reps},{workout.sets},{workout.duration},{workout.calories}\n")
        print("✅ Data saved successfully in", self.filename)

    def view_workouts(self):
        if not self.workouts:
            print("❌ No workout data found.")
            return
        print(f"\n📋 {self.user_name}'s Workout History:")
        for workout in self.workouts:
            print(workout)
