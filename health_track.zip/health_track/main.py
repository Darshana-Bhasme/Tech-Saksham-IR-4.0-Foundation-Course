from fitness_tracker import FitnessTracker

def main():
    user_name = input("Enter your name: ")
    user_age = input("Enter your age: ")
    print(f"👋 Welcome, {user_name}! Age: {user_age}")

    tracker = FitnessTracker(user_name, user_age)

    while True:
        print("\n1. Add Workout\n2. Load Data\n3. Save Data\n4. View Data\n5. Exit")
        choice = input("Choose an option: ")

        if choice == "1":
            tracker.add_workout()
        elif choice == "2":
            tracker.load_from_file()
        elif choice == "3":
            tracker.save_to_file()
        elif choice == "4":
            tracker.view_workouts()
        elif choice == "5":
            print("👋 Exiting... Have a great day!")
            break
        else:
            print("❌ Invalid choice! Try again.")

if __name__ == "__main__":
    main()
